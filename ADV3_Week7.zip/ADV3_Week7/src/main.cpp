#include <Arduino.h>
#include "motor_control.h"
#include "path_func.h"


void setup()
{
    Serial.begin(115200);
    motorSetup(15000, 5000);


    homePosition();
    delay(1000);
    Rotate(80);
    delay(1000);
    Rotate(0);
    delay(1000);
    Gripped(150);
    delay(500);

    
   
   
    ///////////////////////////////////
    
}

void loop()
{
   
    
    
}
