#include<Arduino.h>
#include"Path_func.h"
#include"Motor_control.h"

void Path1(){
   
}

void Path2(){
    
    
}

void Path3(){
   
    
}

void Path4(){
    
    
}

