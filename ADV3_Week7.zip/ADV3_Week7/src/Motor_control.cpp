#include "motor_control.h"
#include "path_func.h"

#include <Arduino.h>
#include <AccelStepper.h>
#include <stdint.h>

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

// สร้าง Object PCA9685
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver();

// ตั้งค่า Pulse ของ Servo (ค่ามาตรฐานคือ 150-600)
#define SERVOMIN  150 
#define SERVOMAX  600 
#define SERVO_FREQ 50 

// --- กำหนดช่องสัญญาณ PCA9685 (แก้ไขตามหน้าที่ใหม่) ---
// myservo1 = Rotate Z (เดิม pin 12) -> ให้เสียบช่อง 0
#define SERVO_ROTATE_CHANNEL 0  

// myservo2 = Gripper (เดิม pin 13) -> ให้เสียบช่อง 1
#define SERVO_GRIPPER_CHANNEL 1 
// --------------------------------------------------

#define MOTORX_STEP_PIN 2
#define MOTORX_DIR_PIN 5
#define MOTORY_STEP_PIN 3
#define MOTORY_DIR_PIN 6
#define MOTORZ_STEP_PIN 4
#define MOTORZ_DIR_PIN 7
#define MOTOR_EN_PIN A1

#define LIMITSWITCHX_PIN 9
#define LIMITSWITCHY_PIN 10
#define LIMITSWITCHZ_PIN 11
#define INTERRUPT_PIN 99

int MICROSTEP_RES = 16;
int STEPRATE = 50;
int STEP_INCREMENT = 100;
int TO_MILLI = 10;

float WORKSPACE_MAX_X = 180.00;
float WORKSPACE_MAX_Y = 185.00;
float WORKSPACE_MAX_Z = 165.00;

float REDZONE_MIN_X = 2.5;
float REDZONE_MAX_X = 15;
float REDZONE_MIN_Y = 12;
float REDZONE_MAX_Y = 18;

volatile bool INTERRUPT_FLAG = false;

AccelStepper MOTORX(AccelStepper::DRIVER, MOTORX_STEP_PIN, MOTORX_DIR_PIN);
AccelStepper MOTORY(AccelStepper::DRIVER, MOTORY_STEP_PIN, MOTORY_DIR_PIN);
AccelStepper MOTORZ(AccelStepper::DRIVER, MOTORZ_STEP_PIN, MOTORZ_DIR_PIN);

// ฟังก์ชันแปลงองศาเป็น Pulse
int degreeToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void motorSetup(uint16_t maxSpeed, uint16_t maxAccel)
{
  pinMode(LIMITSWITCHX_PIN, INPUT_PULLUP);
  pinMode(LIMITSWITCHY_PIN, INPUT_PULLUP);
  pinMode(LIMITSWITCHZ_PIN, INPUT_PULLUP);
  
  MOTORX.setMaxSpeed(maxSpeed);
  MOTORY.setMaxSpeed(maxSpeed);
  MOTORZ.setMaxSpeed(maxSpeed);
  MOTORX.setAcceleration(maxAccel);
  MOTORY.setAcceleration(maxAccel);
  MOTORZ.setAcceleration(maxAccel);

  // Setup PCA9685
  pwm.begin();
  pwm.setOscillatorFrequency(27000000);
  pwm.setPWMFreq(SERVO_FREQ);  
  delay(10);
  
  pinMode(MOTOR_EN_PIN, OUTPUT);
}

void conveyor_load_in()
{
  digitalWrite(MOTOR_EN_PIN, HIGH);
  delay(2000);
  digitalWrite(MOTOR_EN_PIN, LOW);
  delay(10000);
  digitalWrite(MOTOR_EN_PIN, HIGH);
  delay(2000);
}
void conveyor_load_out()
{
  digitalWrite(MOTOR_EN_PIN, HIGH);
  delay(2000);
  digitalWrite(MOTOR_EN_PIN, LOW);
  delay(10500);
  digitalWrite(MOTOR_EN_PIN, HIGH);
  delay(2000);
}
void conveyor_off()
{
  digitalWrite(MOTOR_EN_PIN, HIGH);
  delay(2000);
}

void homePosition()
{
  //------------Z Process -------------//
  MOTORZ.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHZ_PIN) == HIGH)
  {
    MOTORZ.runSpeed();
  }

  MOTORZ.setCurrentPosition(0);
  //------------Y Process -------------//
  MOTORY.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHY_PIN) == HIGH)
  {
    MOTORY.runSpeed();
  }
  MOTORY.setCurrentPosition(0);

  //------------X Process -------------//
  MOTORX.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHX_PIN) == HIGH)
  {
    MOTORX.runSpeed();
  }
  MOTORX.setCurrentPosition(0);

  //----------------------------------//
  moveTomm(82, 45, 3);
  MOTORX.setCurrentPosition(0);
  MOTORY.setCurrentPosition(0);
  MOTORZ.setCurrentPosition(0);
  Serial.println("Sethome position");
  delay(1000);
}

void moveTomm(float targetX, float targetY, float targetZ)
{
  if (targetX <= WORKSPACE_MAX_X && targetY <= WORKSPACE_MAX_Y && targetZ <= WORKSPACE_MAX_Z)
  {
    MOTORX.setSpeed(5000);
    MOTORY.setSpeed(5000);
    MOTORZ.setSpeed(5000);

    float stepsX = targetX * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsY = targetY * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsZ = targetZ * MICROSTEP_RES * STEPRATE / TO_MILLI;

    MOTORX.moveTo(stepsX);
    MOTORY.moveTo(stepsY);
    MOTORZ.moveTo(stepsZ);

    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
      if (INTERRUPT_FLAG)
      {
        interruptLoop();
        Serial.println("Cartesian was interrupted..!");
        resetBoard();
      }
      else
      {
        MOTORX.run();
        MOTORY.run();
        MOTORZ.run();
      }
    }

    Serial.print("X: "); Serial.print(targetX);
    Serial.print(" mm, y: "); Serial.print(targetY);
    Serial.print(" mm, Z: "); Serial.print(targetZ);
    Serial.println(" mm");
  }
  else
  {
    Serial.print("Error: Coordinate Exceeds limits");
  }
}

// --- ส่วนที่แก้ไขฟังก์ชันควบคุม Servo ให้ตรงกับหน้าที่ ---

void Gripped(float pos)
{
  // Gripper ใช้ myservo2 เดิม -> ตอนนี้คือ SERVO_GRIPPER_CHANNEL (Channel 1)
  // ปกติ Gripper: 50 [ grasp ] --- 120 [ release ]
  int pulse = degreeToPulse((int)pos);
  pwm.setPWM(SERVO_GRIPPER_CHANNEL, 0, pulse); 
}

void Rotate(float pos)
{
  // Rotate Z ใช้ myservo1 เดิม -> ตอนนี้คือ SERVO_ROTATE_CHANNEL (Channel 0)
  // ปกติ Rotate: 9 [ 0 deg.] --- 102 [ 90 deg.]
  int pulse = degreeToPulse((int)pos);
  pwm.setPWM(SERVO_ROTATE_CHANNEL, 0, pulse);
}

void interruptLoop()
{
  INTERRUPT_FLAG = true; 
}

void resetBoard()
{
  Serial.println("Arduino reset...");
  delay(1000);
  asm volatile("  jmp 0"); 
}