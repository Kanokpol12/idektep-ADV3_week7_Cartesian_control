#ifndef PATH_FUNC_H
#define PATH_FUNC_H

void Path1();

void Path2();

void Path3();

void Path4();





#endif