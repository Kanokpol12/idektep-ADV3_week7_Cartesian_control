#include <Arduino.h>

const int sensor2 = 6;
const int sensor3 = 5;
const int motorPin1 = 8;
const int motorPin2 = 9;

// ประกาศฟังก์ชันไว้ก่อนเรียกใช้
void Conveyor_on();
void Conveyor_off();

void setup()
{
  pinMode(sensor2, INPUT);
  pinMode(sensor3, INPUT);
  pinMode(motorPin1, OUTPUT);
  pinMode(motorPin2, OUTPUT);
  
  Serial.begin(115200);
  Serial.println("System Ready: Auto Mode Only");
}

void loop()
{
  // อ่านค่าจากเซ็นเซอร์
  int s2_Status = digitalRead(sensor2);
  int s3_Status = digitalRead(sensor3);

  // เงื่อนไข: ถ้าเซ็นเซอร์ตัวใดตัวหนึ่งเจอวัตถุ (HIGH)
  if (s2_Status == HIGH || s3_Status == HIGH) 
  {
    Serial.println("⚠️ Object Detected -> STOP 0.5s");
    
    // 1. สั่งหยุดทันที
    Conveyor_off();
    
    delay(300); 
  }
  else 
  {
    // กรณีไม่เจอวัตถุ ให้ทำงานตลอด
    Conveyor_on();
  }
}

// --- ฟังก์ชันสั่งมอเตอร์ ---

void Conveyor_on()
{
  digitalWrite(motorPin1, HIGH);
  digitalWrite(motorPin2, LOW);
}

void Conveyor_off()
{
  digitalWrite(motorPin1, LOW);
  digitalWrite(motorPin2, LOW);
}